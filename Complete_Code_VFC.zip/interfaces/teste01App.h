//---------------------------------------------------------------------------
//
// Name:        teste01App.h
// Author:      Jeferson Diehl de Oliveira
// Created:     5/6/2020 1:03:42 AM
// Description: 
//
//---------------------------------------------------------------------------

#ifndef __TESTE01FRMApp_h__
#define __TESTE01FRMApp_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
#else
	#include <wx/wxprec.h>
#endif

class teste01FrmApp : public wxApp
{
	public:
		bool OnInit();
		int OnExit();
};

#endif
