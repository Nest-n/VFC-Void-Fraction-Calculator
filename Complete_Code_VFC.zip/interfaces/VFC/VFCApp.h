//---------------------------------------------------------------------------
//
// Name:        VFCApp.h
// Author:      Jeferson Diehl de Oliveira
// Created:     5/18/2020 10:51:03 PM
// Description: 
//
//---------------------------------------------------------------------------

#ifndef __VFCFRMApp_h__
#define __VFCFRMApp_h__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
#else
	#include <wx/wxprec.h>
#endif

class VFCFrmApp : public wxApp
{
	public:
		bool OnInit();
		int OnExit();
};

#endif
