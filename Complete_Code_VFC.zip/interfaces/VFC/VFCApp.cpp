//---------------------------------------------------------------------------
//
// Name:        VFCApp.cpp
// Author:      Jeferson Diehl de Oliveira
// Created:     5/18/2020 10:51:03 PM
// Description: 
//
//---------------------------------------------------------------------------

#include "VFCApp.h"
#include "VFCFrm.h"

IMPLEMENT_APP(VFCFrmApp)

bool VFCFrmApp::OnInit()
{
    VFCFrm* frame = new VFCFrm(NULL);
    SetTopWindow(frame);
    frame->Show();
    return true;
}
 
int VFCFrmApp::OnExit()
{
	return 0;
}
