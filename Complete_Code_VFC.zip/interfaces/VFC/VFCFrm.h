///-----------------------------------------------------------------
///
/// @file      VFCFrm.h
/// @author    Jeferson Diehl de Oliveira
/// Created:   5/18/2020 10:51:04 PM
/// @section   DESCRIPTION
///            VFCFrm class declaration
///
///------------------------------------------------------------------

#ifndef __VFCFRM_H__
#define __VFCFRM_H__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/frame.h>
#else
	#include <wx/wxprec.h>
#endif

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/textctrl.h>
#include <wx/stattext.h>
#include <wx/button.h>
////Header Include End

////Dialog Style Start
#undef VFCFrm_STYLE
#define VFCFrm_STYLE wxCAPTION | wxRESIZE_BORDER | wxSYSTEM_MENU | wxSTAY_ON_TOP | wxMINIMIZE_BOX | wxMAXIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class VFCFrm : public wxFrame
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		VFCFrm(wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("VFC"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = VFCFrm_STYLE);
		virtual ~VFCFrm();
		void WxButton1Click(wxCommandEvent& event);
		void WxButton2Click(wxCommandEvent& event);
		void VFCFrmActivate(wxActivateEvent& event);
		
	private:
		//Do not add custom control declarations between
		//GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxStaticText *WxStaticText22;
		wxTextCtrl *WxEdit9;
		wxStaticText *WxStaticText21;
		wxStaticText *WxStaticText20;
		wxStaticText *WxStaticText19;
		wxTextCtrl *WxEdit8;
		wxStaticText *WxStaticText18;
		wxStaticText *WxStaticText17;
		wxTextCtrl *WxEdit7;
		wxStaticText *WxStaticText16;
		wxStaticText *WxStaticText15;
		wxTextCtrl *WxEdit6;
		wxStaticText *WxStaticText14;
		wxStaticText *WxStaticText13;
		wxStaticText *WxStaticText12;
		wxTextCtrl *WxEdit5;
		wxStaticText *WxStaticText11;
		wxTextCtrl *WxEdit4;
		wxStaticText *WxStaticText10;
		wxTextCtrl *WxEdit3;
		wxTextCtrl *WxEdit2;
		wxTextCtrl *WxEdit1;
		wxStaticText *WxStaticText9;
		wxStaticText *WxStaticText8;
		wxStaticText *WxStaticText7;
		wxStaticText *WxStaticText6;
		wxStaticText *WxStaticText5;
		wxStaticText *WxStaticText4;
		wxStaticText *WxStaticText3;
		wxStaticText *WxStaticText2;
		wxStaticText *WxStaticText1;
		wxButton *WxButton1;
		////GUI Control Declaration End
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_WXSTATICTEXT22 = 1034,
			ID_WXEDIT9 = 1032,
			ID_WXSTATICTEXT21 = 1031,
			ID_WXSTATICTEXT20 = 1030,
			ID_WXSTATICTEXT19 = 1029,
			ID_WXEDIT8 = 1028,
			ID_WXSTATICTEXT18 = 1027,
			ID_WXSTATICTEXT17 = 1026,
			ID_WXEDIT7 = 1025,
			ID_WXSTATICTEXT16 = 1024,
			ID_WXSTATICTEXT15 = 1023,
			ID_WXEDIT6 = 1022,
			ID_WXSTATICTEXT14 = 1021,
			ID_WXSTATICTEXT13 = 1020,
			ID_WXSTATICTEXT12 = 1019,
			ID_WXEDIT5 = 1018,
			ID_WXSTATICTEXT11 = 1017,
			ID_WXEDIT4 = 1016,
			ID_WXSTATICTEXT10 = 1015,
			ID_WXEDIT3 = 1014,
			ID_WXEDIT2 = 1013,
			ID_WXEDIT1 = 1012,
			ID_WXSTATICTEXT9 = 1011,
			ID_WXSTATICTEXT8 = 1010,
			ID_WXSTATICTEXT7 = 1008,
			ID_WXSTATICTEXT6 = 1007,
			ID_WXSTATICTEXT5 = 1006,
			ID_WXSTATICTEXT4 = 1005,
			ID_WXSTATICTEXT3 = 1004,
			ID_WXSTATICTEXT2 = 1003,
			ID_WXSTATICTEXT1 = 1002,
			ID_WXBUTTON1 = 1001,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};
		
	private:
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
};

#endif
