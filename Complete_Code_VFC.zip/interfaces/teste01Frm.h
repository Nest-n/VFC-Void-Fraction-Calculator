///-----------------------------------------------------------------
///
/// @file      teste01Frm.h
/// @author    Jeferson Diehl de Oliveira
/// Created:   5/6/2020 1:03:43 AM
/// @section   DESCRIPTION
///            teste01Frm class declaration
///
///------------------------------------------------------------------

#ifndef __TESTE01FRM_H__
#define __TESTE01FRM_H__

#ifdef __BORLANDC__
	#pragma hdrstop
#endif

#ifndef WX_PRECOMP
	#include <wx/wx.h>
	#include <wx/frame.h>
#else
	#include <wx/wxprec.h>
#endif

//Do not add custom headers between 
//Header Include Start and Header Include End.
//wxDev-C++ designer will remove them. Add custom headers after the block.
////Header Include Start
#include <wx/stattext.h>
#include <wx/button.h>
#include <wx/textctrl.h>
////Header Include End

////Dialog Style Start
#undef teste01Frm_STYLE
#define teste01Frm_STYLE wxCAPTION | wxRESIZE_BORDER | wxSYSTEM_MENU | wxSTAY_ON_TOP | wxMINIMIZE_BOX | wxMAXIMIZE_BOX | wxCLOSE_BOX
////Dialog Style End

class teste01Frm : public wxFrame
{
	private:
		DECLARE_EVENT_TABLE();
		
	public:
		teste01Frm(wxWindow *parent, wxWindowID id = 1, const wxString &title = wxT("teste01"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = teste01Frm_STYLE);
		virtual ~teste01Frm();
		void WxListBox1Selected(wxCommandEvent& event);
		void WxBitmapButton1Click(wxCommandEvent& event);
		void WxButton1Click(wxCommandEvent& event);
		void WxEdit3Updated(wxCommandEvent& event);
		void WxButton2Click(wxCommandEvent& event);
		void WxBitmapButton1Click0(wxCommandEvent& event);
		void WxEdit1Updated(wxCommandEvent& event);
		void WxEdit1Updated0(wxCommandEvent& event);
		void WxButton3Click(wxCommandEvent& event);
		void WxButton3Click0(wxCommandEvent& event);
		void WxEdit6Updated(wxCommandEvent& event);
		//void WxHyperLinkCtrl1HyperLink(wxHyperlinkEvent& event);
		
	private:
		//Do not add custom control declarations between
		//GUI Control Declaration Start and GUI Control Declaration End.
		//wxDev-C++ will remove them. Add custom code after the block.
		////GUI Control Declaration Start
		wxStaticText *WxStaticText22;
		wxStaticText *WxStaticText21;
		wxStaticText *WxStaticText20;
		wxTextCtrl *WxEdit9;
		wxStaticText *WxStaticText19;
		wxStaticText *WxStaticText18;
		wxTextCtrl *WxEdit8;
		wxStaticText *WxStaticText17;
		wxStaticText *WxStaticText16;
		wxTextCtrl *WxEdit7;
		wxStaticText *WxStaticText15;
		wxStaticText *WxStaticText14;
		wxStaticText *WxStaticText13;
		wxStaticText *WxStaticText12;
		wxStaticText *WxStaticText1;
		wxTextCtrl *WxEdit6;
		wxStaticText *WxStaticText11;
		wxStaticText *WxStaticText10;
		wxTextCtrl *WxEdit3;
		wxStaticText *WxStaticText9;
		wxStaticText *WxStaticText8;
		wxStaticText *WxStaticText7;
		wxStaticText *WxStaticText6;
		wxStaticText *WxStaticText5;
		wxStaticText *WxStaticText4;
		wxStaticText *WxStaticText3;
		wxStaticText *WxStaticText2;
		wxTextCtrl *WxEdit5;
		wxTextCtrl *WxEdit4;
		wxButton *WxButton2;
		wxButton *WxButton1;
		wxTextCtrl *WxEdit2;
		wxTextCtrl *WxEdit1;
		////GUI Control Declaration End
		
	private:
		//Note: if you receive any error with these enum IDs, then you need to
		//change your old form code that are based on the #define control IDs.
		//#defines may replace a numeric value for the enum names.
		//Try copy and pasting the below block in your old form header files.
		enum
		{
			////GUI Enum Control ID Start
			ID_WXSTATICTEXT22 = 1055,
			ID_WXSTATICTEXT21 = 1054,
			ID_WXSTATICTEXT20 = 1053,
			ID_WXEDIT9 = 1052,
			ID_WXSTATICTEXT19 = 1048,
			ID_WXSTATICTEXT18 = 1047,
			ID_WXEDIT8 = 1046,
			ID_WXSTATICTEXT17 = 1042,
			ID_WXSTATICTEXT16 = 1041,
			ID_WXEDIT7 = 1040,
			ID_WXSTATICTEXT15 = 1036,
			ID_WXSTATICTEXT14 = 1035,
			ID_WXSTATICTEXT13 = 1034,
			ID_WXSTATICTEXT12 = 1033,
			ID_WXSTATICTEXT1 = 1032,
			ID_WXEDIT6 = 1031,
			ID_WXSTATICTEXT11 = 1027,
			ID_WXSTATICTEXT10 = 1026,
			ID_WXEDIT3 = 1025,
			ID_WXSTATICTEXT9 = 1019,
			ID_WXSTATICTEXT8 = 1018,
			ID_WXSTATICTEXT7 = 1017,
			ID_WXSTATICTEXT6 = 1016,
			ID_WXSTATICTEXT5 = 1015,
			ID_WXSTATICTEXT4 = 1014,
			ID_WXSTATICTEXT3 = 1013,
			ID_WXSTATICTEXT2 = 1012,
			ID_WXEDIT5 = 1011,
			ID_WXEDIT4 = 1009,
			ID_WXBUTTON2 = 1007,
			ID_WXBUTTON1 = 1003,
			ID_WXEDIT2 = 1002,
			ID_WXEDIT1 = 1001,
			////GUI Enum Control ID End
			ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
		};
		
	private:
		void OnClose(wxCloseEvent& event);
		void CreateGUIControls();
};

#endif
