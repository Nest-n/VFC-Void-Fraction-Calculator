//---------------------------------------------------------------------------
//
// Name:        teste01App.cpp
// Author:      Jeferson Diehl de Oliveira
// Created:     5/6/2020 1:03:42 AM
// Description: 
//
//---------------------------------------------------------------------------

#include "teste01App.h"
#include "teste01Frm.h"

IMPLEMENT_APP(teste01FrmApp)

bool teste01FrmApp::OnInit()
{
    teste01Frm* frame = new teste01Frm(NULL);
    SetTopWindow(frame);
    frame->Show();
    return true;
}
 
int teste01FrmApp::OnExit()
{
	return 0;
}
