///-----------------------------------------------------------------
///
/// @file      Untitled2Frm.cpp
/// @author    Jeferson Diehl de Oliveira
/// Created:   5/10/2020 10:31:31 PM
/// @section   DESCRIPTION
///            Untitled2Frm class implementation
///
///------------------------------------------------------------------

#include "Untitled2Frm.h"

//Do not add custom headers between
//Header Include Start and Header Include End
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// Untitled2Frm
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(Untitled2Frm,wxFrame)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(Untitled2Frm::OnClose)
END_EVENT_TABLE()
////Event Table End

Untitled2Frm::Untitled2Frm(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxFrame(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

Untitled2Frm::~Untitled2Frm()
{
}

void Untitled2Frm::CreateGUIControls()
{
	//Do not add custom code between
	//GUI Items Creation Start and GUI Items Creation End
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	SetTitle(_("Density of saturated liquid"));
	SetIcon(wxNullIcon);
	SetSize(31,0,650,334);
	Center();
	
	////GUI Items Creation End
}

void Untitled2Frm::OnClose(wxCloseEvent& event)
{
	Destroy();
}

/*
 * WxRichTextCtrl1BufferReset
 */


/*
 * WxEdit1Updated
 */
void Untitled2Frm::WxEdit1Updated(wxCommandEvent& event)
{
	// insert your code here
}

/*
 * WxHtmlWindow1UpdateUI
 */

/*
 * WxScrolledWindow1UpdateUI
 */
void Untitled2Frm::WxScrolledWindow1UpdateUI(wxUpdateUIEvent& event)
{
	// insert your code here
}


